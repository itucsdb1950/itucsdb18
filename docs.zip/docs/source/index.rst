Welcome to itucsdb1950's documentation!
========================================

:Team: Klasse

:Members:

   * Kutay KARAKAMIŞ
   * Mehmet Fatih YILDIRIM
   * Enes Furkan ÖRNEK

**WELCOME TO KLASSE PROJECT DOCUMENTATION**

.. figure:: ./ss/uni_student.jpg
  :scale: 100%
  :alt: map to buried treasure


**In Klasse project, students' personal information, grades taken from homeworks, exams, etc. and other information will be stored. System aims to minimize the loss of time with paper works during the course. Students will be able to enroll to classes, see the classes they are enrolled, the grades they have taken from homeworks, exams, etc., food menu list and personal information along with their GPAs. They will have access to all the information they need through a single system.**

**The project is implemented in a way that admins can do the necessary changes, updates, etc. They can create, read and delete new faculties, classes, people, grades, foods, food menus and locations; update faculties, classes, locations in the database. On the other hand, students can create enrollments, read classes, grades, and food menus.**

Contents:

.. toctree::
   :maxdepth: 1

   user/index
   developer/index
