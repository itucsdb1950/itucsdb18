User Guide
==========
**This section covers knowledge of using website.**

Login Page
__________

Here is our login page which you can enter as an admin with username = kkarakamis and password = 1234 entries.

.. figure:: ../ss/intro.png
  :scale: 50 %
  :alt: map to buried treasure

  http://itucsdb1950.herokuapp.com/


.. toctree::

   member1
   member2
   member3
   
